var led_8h =
[
    [ "led_blink_t", "group___l_e_d___a_p_i.html#ga5f004cf02ead0a9d8adbc41fa0c55afd", [
      [ "eLED_BLINK_1X", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afdade7f04103d69388ebd1aaf94d6b4a77a", null ],
      [ "eLED_BLINK_2X", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afda26489bf9afc6819ac41e66f740faa499", null ],
      [ "eLED_BLINK_3X", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afdad39b73561733306fcccff92d3182e913", null ],
      [ "eLED_BLINK_4X", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afda4b89a901c8c59aa00ebe2364611d3b91", null ],
      [ "eLED_BLINK_5X", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afda4f76c52fab5637fedbc4de7dcb73765e", null ],
      [ "eLED_BLINK_CONTINUOUS", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afda42b4f4b031051fe40b9b31f60c28b11a", null ],
      [ "eLED_BLINK_NUM_OF", "group___l_e_d___a_p_i.html#gga5f004cf02ead0a9d8adbc41fa0c55afdaa597b5df0719e24180c4378aefb9126b", null ]
    ] ],
    [ "led_drv_t", "group___l_e_d___a_p_i.html#gaceca637f58c4dcb25ac354bbf922835b", [
      [ "eLED_DRV_GPIO", "group___l_e_d___a_p_i.html#ggaceca637f58c4dcb25ac354bbf922835badbf083dc9a032ee5ab2e4039f7903f68", null ],
      [ "eLED_DRV_TIMER_PWM", "group___l_e_d___a_p_i.html#ggaceca637f58c4dcb25ac354bbf922835ba20e035d393f98a3dd480e9b456ee4d8e", null ],
      [ "eLED_DRV_NUM_OF", "group___l_e_d___a_p_i.html#ggaceca637f58c4dcb25ac354bbf922835ba3f9a27d830305b006e7cebffd3ec7a53", null ]
    ] ],
    [ "led_polarity_t", "group___l_e_d___a_p_i.html#gaf8b70f054eb5706e8970a1915b0f4cc8", [
      [ "eLED_POL_ACTIVE_HIGH", "group___l_e_d___a_p_i.html#ggaf8b70f054eb5706e8970a1915b0f4cc8adced5195e208411b3b500f787c9b56f9", null ],
      [ "eLED_POL_ACTIVE_LOW", "group___l_e_d___a_p_i.html#ggaf8b70f054eb5706e8970a1915b0f4cc8a452737c58cf181a4728f15a23df5ac97", null ]
    ] ],
    [ "led_state_t", "group___l_e_d___a_p_i.html#ga25dc233a9dc8904b8ce586b61edc282d", [
      [ "eLED_OFF", "group___l_e_d___a_p_i.html#gga25dc233a9dc8904b8ce586b61edc282da7c5e9a36d1a5489bf70585920bc10ccc", null ],
      [ "eLED_ON", "group___l_e_d___a_p_i.html#gga25dc233a9dc8904b8ce586b61edc282da6d4a0b414f694bf27de426e76fe380c0", null ]
    ] ],
    [ "led_status_t", "group___l_e_d___a_p_i.html#gacefcb61df68bbf1e3b464156b1b8c333", [
      [ "eLED_OK", "group___l_e_d___a_p_i.html#ggacefcb61df68bbf1e3b464156b1b8c333a78a5ac87f495aabe7899d7384a6831c6", null ],
      [ "eLED_ERROR", "group___l_e_d___a_p_i.html#ggacefcb61df68bbf1e3b464156b1b8c333a43c1b45397fde73e99f900315974df98", null ],
      [ "eLED_ERROR_INIT", "group___l_e_d___a_p_i.html#ggacefcb61df68bbf1e3b464156b1b8c333a16207e8329d11b6b1d070f1ca0bde25a", null ]
    ] ],
    [ "led_blink", "group___l_e_d___a_p_i.html#ga73cadf7218d22b576049852f82e35307", null ],
    [ "led_blink_smooth", "group___l_e_d___a_p_i.html#gad4080d3566bba96ddf55418cbe7cf1b0", null ],
    [ "led_get_active_time", "group___l_e_d___a_p_i.html#gae945c8a50190b3bfa241cd31d91002e0", null ],
    [ "led_hndl", "group___l_e_d___a_p_i.html#ga635b4d56e81d8b22462e036b74bbda16", null ],
    [ "led_init", "group___l_e_d___a_p_i.html#ga4e777f4090de6b4fa86e01d3ce98d37f", null ],
    [ "led_is_init", "group___l_e_d___a_p_i.html#gac025e6c5d59523a84b21e0380ca79120", null ],
    [ "led_set", "group___l_e_d___a_p_i.html#ga861c8a6ff456afb0bd0e7d7ffb035edb", null ],
    [ "led_set_fade_cfg", "group___l_e_d___a_p_i.html#ga88d3c07f665e6371503ee0ca4685aa09", null ],
    [ "led_set_smooth", "group___l_e_d___a_p_i.html#gaeef00b5be46c911917fdd675d6d7a43a", null ]
];