var structled__t =
[
    [ "active_time", "structled__t.html#a7420c8c7e47fbdf603b05e5a79e124a2", null ],
    [ "blink_cnt", "structled__t.html#a12d1cb2c56298ab8663a56106ec46df5", null ],
    [ "duty", "structled__t.html#af47679c7b67a5b213fb6dd7591c0de61", null ],
    [ "fade_in_k", "structled__t.html#abf5d393bf14c2ab90cb6c69d11721948", null ],
    [ "fade_out_k", "structled__t.html#a572c9d9fc321385d51688b2be134e212", null ],
    [ "fade_out_time", "structled__t.html#a4666f6002acf9275b3aa2f941f677dcc", null ],
    [ "fade_time", "structled__t.html#af0868c3bc887a3581f32c74979784ae5", null ],
    [ "max_duty", "structled__t.html#a7e82eb75076f471368377265661c5c0f", null ],
    [ "mode", "structled__t.html#a7c99fd769c2e5366b7830395d0102e6e", null ],
    [ "on_time", "structled__t.html#a1370ad0f7f4707ca408c9a87f3a54d7f", null ],
    [ "per_time", "structled__t.html#a06df7b74b7c5dad89f2f98c0a8527b54", null ],
    [ "period", "structled__t.html#a89fa6cbeb7db9c3ad952220285992921", null ]
];