var structled__cfg__t =
[
    [ "drv_ch", "structled__cfg__t.html#a43214bd67c586a21de24f709a7cc47e0", null ],
    [ "drv_type", "structled__cfg__t.html#a62570e76802d7bc5032b95a2aa627b48", null ],
    [ "initial_state", "structled__cfg__t.html#a7d7d3054f7bc422d01efaa74592c2cd0", null ],
    [ "polarity", "structled__cfg__t.html#ad0df0b7dc29f42a1b43fc262bff7b9f9", null ]
];