var structled__fade__cfg__t =
[
    [ "fade_in_time", "structled__fade__cfg__t.html#aba3f674f2206531cdd4b978dcf2adcbd", null ],
    [ "fade_out_time", "structled__fade__cfg__t.html#a925611c951a512a18752542b50f7f330", null ],
    [ "max_duty", "structled__fade__cfg__t.html#a2d7d93bb928c0fc8e24990186f5f9268", null ]
];