var annotated_dup =
[
    [ "led_cfg_t", "structled__cfg__t.html", "structled__cfg__t" ],
    [ "led_drv_ch_t", "unionled__drv__ch__t.html", "unionled__drv__ch__t" ],
    [ "led_fade_cfg_t", "structled__fade__cfg__t.html", "structled__fade__cfg__t" ],
    [ "led_t", "structled__t.html", "structled__t" ]
];