var searchData=
[
  ['max_5fduty_84',['max_duty',['../structled__t.html#a7e82eb75076f471368377265661c5c0f',1,'led_t::max_duty()'],['../structled__fade__cfg__t.html#a2d7d93bb928c0fc8e24990186f5f9268',1,'led_fade_cfg_t::max_duty()']]],
  ['mode_85',['mode',['../structled__t.html#a7c99fd769c2e5366b7830395d0102e6e',1,'led_t']]]
];
