var searchData=
[
  ['fade_5fin_5fk_29',['fade_in_k',['../structled__t.html#abf5d393bf14c2ab90cb6c69d11721948',1,'led_t']]],
  ['fade_5fin_5ftime_30',['fade_in_time',['../structled__fade__cfg__t.html#aba3f674f2206531cdd4b978dcf2adcbd',1,'led_fade_cfg_t']]],
  ['fade_5fout_5fk_31',['fade_out_k',['../structled__t.html#a572c9d9fc321385d51688b2be134e212',1,'led_t']]],
  ['fade_5fout_5ftime_32',['fade_out_time',['../structled__t.html#a4666f6002acf9275b3aa2f941f677dcc',1,'led_t::fade_out_time()'],['../structled__fade__cfg__t.html#a925611c951a512a18752542b50f7f330',1,'led_fade_cfg_t::fade_out_time()']]],
  ['fade_5ftime_33',['fade_time',['../structled__t.html#af0868c3bc887a3581f32c74979784ae5',1,'led_t']]]
];
