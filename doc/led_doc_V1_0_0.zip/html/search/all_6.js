var searchData=
[
  ['initial_5fstate_38',['initial_state',['../structled__cfg__t.html#a7d7d3054f7bc422d01efaa74592c2cd0',1,'led_cfg_t']]]
];
