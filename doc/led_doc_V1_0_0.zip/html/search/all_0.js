var searchData=
[
  ['active_5ftime_0',['active_time',['../structled__t.html#a7420c8c7e47fbdf603b05e5a79e124a2',1,'led_t']]]
];
