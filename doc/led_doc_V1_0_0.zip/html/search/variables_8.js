var searchData=
[
  ['per_5ftime_137',['per_time',['../structled__t.html#a06df7b74b7c5dad89f2f98c0a8527b54',1,'led_t']]],
  ['period_138',['period',['../structled__t.html#a89fa6cbeb7db9c3ad952220285992921',1,'led_t']]],
  ['polarity_139',['polarity',['../structled__cfg__t.html#ad0df0b7dc29f42a1b43fc262bff7b9f9',1,'led_cfg_t']]]
];
