var searchData=
[
  ['blink_5fcnt_1',['blink_cnt',['../structled__t.html#a12d1cb2c56298ab8663a56106ec46df5',1,'led_t']]]
];
