var searchData=
[
  ['drv_5fch_2',['drv_ch',['../structled__cfg__t.html#a43214bd67c586a21de24f709a7cc47e0',1,'led_cfg_t']]],
  ['drv_5ftype_3',['drv_type',['../structled__cfg__t.html#a62570e76802d7bc5032b95a2aa627b48',1,'led_cfg_t']]],
  ['duty_4',['duty',['../structled__t.html#af47679c7b67a5b213fb6dd7591c0de61',1,'led_t']]]
];
