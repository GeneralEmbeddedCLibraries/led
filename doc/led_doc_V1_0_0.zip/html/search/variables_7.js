var searchData=
[
  ['on_5ftime_136',['on_time',['../structled__t.html#a1370ad0f7f4707ca408c9a87f3a54d7f',1,'led_t']]]
];
